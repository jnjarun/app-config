package com.example.email;


public class SendEmail {
    public void run(String toAddress, String subject, String body) {

    }
}
