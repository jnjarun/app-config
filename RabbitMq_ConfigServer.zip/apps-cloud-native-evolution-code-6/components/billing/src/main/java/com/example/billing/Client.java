package com.example.billing;

public interface Client {
    void billUser(String userId, int amount);
}
