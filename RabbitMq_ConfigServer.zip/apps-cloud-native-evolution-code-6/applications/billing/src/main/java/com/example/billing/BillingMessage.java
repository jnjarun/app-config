package com.example.billing;

// By keeping this package private, we don't allow it to leak out into other applications.

class BillingMessage {

    private  String userId;
    private  int amount;

  
    public BillingMessage() {

    }

    
    public String getUserId() {
        return userId;
    }

    public int getAmount() {
        return amount;
    }
}
